import os.path
import re
import shutil

from ai.interface.ConstantValues import MOTHERLAND_ID_LENGTH, MOTHERLAND_ID_GENDER_INDEX, TW_ID_LENGTH, \
    TW_ID_GENDER_INDEX, MOTHERLAND_ID_YEAR_START_INDEX, MOTHERLAND_ID_MONTH_START_INDEX, MOTHERLAND_ID_DAY_START_INDEX
from ai.interface.Result import Result
from ai.interface.genericity import M, T
import pandas as pd
import numpy as np

import json
import pyperclip

import logging

log = logging.getLogger(__name__)


def match_idcard_tw(idcard):
    pattern = r'^[A-Z]\d{9}$'
    if re.match(pattern, idcard):
        return True
    else:
        return False


def match_idcard_motherland(idcard):
    pattern = r'^\d{6}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[1-2]\d|3[0-1])\d{4}$'
    if re.match(pattern, idcard):
        return True
    else:
        return False


def fill_information(ner_list: list, r: T):
    if r.idNumber is None or len(r.idNumber.strip()) == 0:
        for item in ner_list:
            if match_idcard_motherland(item[0]) or match_idcard_tw(item[0]):
                r.idNumber = item[0]
                r.gender = fill_gender(r.idNumber)
                r.birthday = fill_birthday(r.idNumber)
                break


def fill_gender(id_number: str) -> str:
    i = 0
    if len(id_number) == MOTHERLAND_ID_LENGTH:
        i = int(id_number[MOTHERLAND_ID_GENDER_INDEX])
    elif len(id_number) == TW_ID_LENGTH:
        i = int(id_number[TW_ID_GENDER_INDEX])
    return '男' if i % 2 == 1 else '女'


def fill_birthday(id_number: str):
    if id_number is not None and len(id_number) == MOTHERLAND_ID_LENGTH:
        year = id_number[MOTHERLAND_ID_YEAR_START_INDEX:MOTHERLAND_ID_YEAR_START_INDEX + 4]
        month = id_number[MOTHERLAND_ID_MONTH_START_INDEX:MOTHERLAND_ID_MONTH_START_INDEX + 2]
        day = id_number[MOTHERLAND_ID_DAY_START_INDEX:MOTHERLAND_ID_DAY_START_INDEX + 2]
        return '-'.join([year, month, day])


def prepare_data(file: pd.ExcelFile):
    df = pd.read_excel(file, sheet_name=0, header=None)
    df.fillna('', inplace=True)
    if log.isEnabledFor(logging.DEBUG):
        log.debug(f"行数{df.shape[0]},列数{df.shape[1]}")
    content = []
    for i in range(0, df.shape[0]):
        row_data = df.iloc[i, :]
        join = ' '.join(str(e) for e in row_data.values)
        content.append(join)
    return content


def save_standard_excel(result: list):
    target_file_name = "standard.xlsx"
    if os.path.exists(target_file_name):
        os.remove(target_file_name)
    target_data = [[x.name, '身份证', x.idNumber, x.birthday, x.gender, x.mobilePhone] for x in result]
    data_frame = pd.DataFrame(data=target_data, index=np.array(np.arange(1, len(target_data) + 1)))
    data_frame.to_excel(target_file_name)


def copy_folder(source_folder, target_folder, check_list):
    copy_flag = False
    if not os.path.exists(target_folder) or not os.path.isdir(target_folder):
        copy_flag = True
    elif os.path.exists(target_folder) and os.path.isdir(target_folder):
        if check_list is not None:
            for item in check_list:
                if not os.path.exists(target_folder + os.path.sep + item):
                    shutil.rmtree(target_folder)
                    if log.isEnabledFor(logging.INFO):
                        log.info(f"删除文件夹{target_folder}")
                    copy_flag = True
                    break
    if copy_flag:
        if log.isEnabledFor(logging.INFO):
            log.info(f"复制文件夹{source_folder}到{target_folder}")
        shutil.copytree(source_folder, target_folder)


def write_clip(content):
    pyperclip.copy(content)


def read_clip():
    return pyperclip.paste()


class ResultEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Result):
            return o.to_json()
        return json.JSONEncoder.default(self, o)
