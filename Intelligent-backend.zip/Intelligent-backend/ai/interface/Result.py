
class Result:
    def __init__(self):
        self.birthday = ''
        self.idNumber = ''
        self.name = ''
        self.age = 0
        self.mobilePhone = ''
        self.address = ''
        self.gender = ''
        self.homeTel = ''

    def to_json(self):
        # return json.dumps(self, default=lambda o: o.__dict__)
        return {
            "name": self.name,
            "idNumber": self.idNumber,
            "age": self.age,
            "birthday": self.birthday,
            "mobilePhone": self.mobilePhone,
            "homeTel": self.homeTel,
            "address": self.address,
            "gender": self.gender
        }
