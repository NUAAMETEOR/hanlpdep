from typing import TypeVar

from ai.interface.Result import Result

T = TypeVar('T', bound=Result)
M = TypeVar('M')
