from __future__ import annotations

import json
from abc import ABCMeta, abstractmethod
from typing import TypeVar, List
import pandas
from hanlp.components.ner.transformer_ner import TransformerNamedEntityRecognizer
import logging

from ai.interface.Result import Result
from ai.interface.genericity import M, T
from ai.utils.utils import fill_information


class IntellRecognize(metaclass=ABCMeta):
    def __init__(self):
        self._log = logging.getLogger(__name__)
        self._model: M = self.load_model()
        self._log.info(f'加载模型成功,模型类型${self._model.__class__.__name__}')

    def fit(self):
        raise NotImplementedError

    @abstractmethod
    def predict(self, data):
        raise NotImplementedError
#
# {'MSRA_NER_BERT_BASE_ZH': 'https://file.hankcs.com/hanlp/ner/ner_bert_base_msra_20211227_114712.zip',
#  'MSRA_NER_ALBERT_BASE_ZH': 'https://file.hankcs.com/hanlp/ner/msra_ner_albert_base_20211228_173323.zip',
#  'MSRA_NER_ELECTRA_SMALL_ZH': 'https://file.hankcs.com/hanlp/ner/msra_ner_electra_small_20210807_154832.zip',
#  'CONLL03_NER_BERT_BASE_CASED_EN': 'https://file.hankcs.com/hanlp/ner/ner_conll03_bert_base_cased_en_20211227_121443.zip'}
    @abstractmethod
    def load_model(self) -> M:
        raise NotImplementedError

    @abstractmethod
    def recognize(self, origin: str | pandas.ExcelFile, result_type: T) -> List[T]:
        raise NotImplementedError

    @abstractmethod
    def customize(self, ner: TransformerNamedEntityRecognizer):
        pass

    def convert_result(self, content: List[str], result_type: T = Result) -> List[T]:
        if content is not None and len(content) > 0:
            prediction = self.predict(content)
            if self._log.isEnabledFor(logging.DEBUG):
                if hasattr(prediction, 'pretty_print'):
                    prediction.pretty_print()
                else:
                    self._log.debug(json.dumps(prediction))
            result_list = []
            if prediction is not None and len(prediction) > 0:
                for l in prediction:
                    result = result_type()
                    for item in l:
                        if item[1] == 'PERSON':
                            result.name = item[0]
                        elif item[1] == 'TIME' or item[1] == 'DATE':
                            result.birthday = item[0]
                        elif item[1] == 'LOCATION':
                            result.address = result.address + item[0]
                    if len(l) > 0:
                        fill_information(l, result)
                        result_list.append(result)
            return result_list
        return []
