from typing import List

import hanlp
import pandas
from hanlp.components.ner.transformer_ner import TransformerNamedEntityRecognizer

from ai.interface.IntellRecognize import IntellRecognize, Result, T


class HanlpStrIntelliRecognize(IntellRecognize):

    def __init__(self):
        super().__init__()
        self.task_name = 'ner/msra'

    def recognize(self, origin: str, result_type: T) -> List[T]:
        split = origin.split('\n')
        result = self.convert_result(split, result_type)
        return result

    def predict(self, data):
        document = self._model(data, tasks=self.task_name)
        return document[self.task_name]

    def load_model(self):
        # return  self._model = hanlp.load(hanlp.pretrained.ner.MSRA_NER_BERT_BASE_ZH)
        # return  self._model = hanlp.load(hanlp.pretrained.ner.MSRA_NER_ALBERT_BASE_ZH)
        return hanlp.load(hanlp.pretrained.mtl.CLOSE_TOK_POS_NER_SRL_DEP_SDP_CON_ERNIE_GRAM_ZH)
        # return  self._model = hanlp.load('/Users/ak47/Downloads/ner_albert_base_zh_msra_20200111_202919')

    def customize(self, ner: TransformerNamedEntityRecognizer):
        pass
