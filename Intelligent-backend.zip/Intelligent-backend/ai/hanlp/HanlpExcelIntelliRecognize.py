import logging
from typing import List

import hanlp
import pandas
from hanlp.components.mtl.tasks.ner.tag_ner import TaggingNamedEntityRecognition

from ai.interface.IntellRecognize import IntellRecognize, T
from ai.interface.Result import Result
from ai.utils.utils import prepare_data, fill_information, save_standard_excel


class HanlpExcelIntelliRecognize(IntellRecognize):

    def predict(self, data):
        document = self._model(data, tasks=self.task_name)
        return document[self.task_name]

    def load_model(self):
        return hanlp.load(hanlp.pretrained.mtl.CLOSE_TOK_POS_NER_SRL_DEP_SDP_CON_ERNIE_GRAM_ZH)

    def __init__(self):
        super().__init__()
        # self.task_name = 'ner/ontonotes'
        self.task_name = 'ner/msra'

    def recognize(self, file: pandas.ExcelFile, result_type: T = Result) -> List[T]:
        result = self.convert_result(prepare_data(file), result_type)
        save_standard_excel(result)
        return result

    def customize(self, model: hanlp.common.component.Component):
        ner: TaggingNamedEntityRecognition = model['ner/msra']
        ner.dict_tags = {('名字', '叫', '金华'): ('O', 'O', 'S-PERSON')}
        # ner.dict_whitelist = {'午饭后': 'TIME'}
        model('他在浙江金华出生，他的名字叫金华。', tasks='ner/msra').pretty_print()

    # def convert_document(self, content: List[str]) -> list:
    #     if content is not None and len(content) > 0:
    #         doc = self._model(content, tasks=self.task_name)
    #         doc.pretty_print()
    #         print(doc[self.task_name])
    #         return doc
    #
    # def create_result(self, document, result_type: T = Result) -> List[T]:
    #     result_list = []
    #     if document is not None and len(document[self.task_name]) > 0:
    #         for l in document[self.task_name]:
    #             result = result_type()
    #             for item in l:
    #                 if item[1] == 'PERSON':
    #                     result.name = item[0]
    #                 elif item[1] == 'TIME' or item[1] == 'DATE':
    #                     result.birthday = item[0]
    #                 elif item[1] == 'LOCATION':
    #                     result.address = result.address + item[0]
    #             if len(l) > 0:
    #                 fill_information(l, result)
    #                 result_list.append(result)
    #     return result_list
