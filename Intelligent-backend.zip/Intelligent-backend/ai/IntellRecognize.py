import json
from abc import ABCMeta, abstractmethod

import pandas
from hanlp.components.ner.transformer_ner import TransformerNamedEntityRecognizer

MOTHERLAND_ID_LENGTH = 18
MOTHERLAND_ID_GENDER_INDEX = 16
MOTHERLAND_ID_YEAR_START_INDEX = 6
MOTHERLAND_ID_MONTH_START_INDEX = 10
MOTHERLAND_ID_DAY_START_INDEX = 12
TW_ID_LENGTH = 10
TW_ID_GENDER_INDEX = 1


class Result:
    def __init__(self):
        self.birthday = ''
        self.idNumber = ''
        self.name = ''
        self.age = 0
        self.mobilePhone = ''
        self.address = ''
        self.gender = ''
        self.homeTel = ''

    def to_json(self):
        # return json.dumps(self, default=lambda o: o.__dict__)
        return {
            "name": self.name,
            "idNumber": self.idNumber,
            "age": self.age,
            "birthday": self.birthday,
            "mobilePhone": self.mobilePhone,
            "homeTel": self.homeTel,
            "address": self.address,
            "gender": self.gender
        }


class IntellRecognize(metaclass=ABCMeta):
    def fit(self):
        raise NotImplementedError

    @abstractmethod
    def recognize_excel_file(self, file: pandas.ExcelFile) -> Result:
        pass

    @abstractmethod
    def customize(self, ner: TransformerNamedEntityRecognizer):
        pass
