import traceback

import hanlp
import logging

from ai.hanlp.HanlpExcelIntelliRecognize import HanlpExcelIntelliRecognize
from ai.hanlp.HanlpStrIntelliRecognize import HanlpStrIntelliRecognize
from ai.interface.IntellRecognize import IntellRecognize
from ai.interface.Result import Result

logging.basicConfig(
    level=logging.DEBUG,  # 设置日志级别，这里设置为DEBUG，可以记录DEBUG及以上级别的日志
    format='%(asctime)s -%(name)s- %(levelname)s - %(message)s',  # 设置日志格式
    datefmt='%Y-%m-%d %H:%M:%S',  # 设置时间格式
    filename=None,  # 指定日志文件名，如'app.log'，如果不设置则默认输出到控制台,
    filemode='w'  # 指定文件模式，'w'或'a'，'w'表示每次运行都会清空原日志文件重新写入，'a'表示追加模式
)


class OnlineDeploy(object):
    __instance: IntellRecognize = None
    __init_flag = False
    __model = None

    def __init__(self):
        if OnlineDeploy.__init_flag:
            return
        OnlineDeploy.__model = HanlpStrIntelliRecognize()
        OnlineDeploy.__init_flag = True

    def __new__(cls, *args, **kwargs):
        if OnlineDeploy.__instance is None:
            OnlineDeploy.__instance = object.__new__(cls)
        return OnlineDeploy.__instance

    def predict(self, data):
        return OnlineDeploy.__model.recognize(data, Result)


def deploy_main(data):
    error_log = ''
    try:
        online_deploy = OnlineDeploy()
        result = online_deploy.predict(data)
        result_dict = {"code": 200, "message": "success", "result": result}
    except:
        error_log = str(traceback.format_exc())
        result_dict = {"code": 99999, "message": 'failed', "result": {}}
        logging.error(error_log)
    return result_dict, error_log
