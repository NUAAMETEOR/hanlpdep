from flask import Flask
import os
import pandas as pd
import json
import pyperclip
from ai.hanlp.HanlpExcelIntelliRecognize import HanlpExcelIntelliRecognize
from ai.hanlp.HanlpStrIntelliRecognize import HanlpStrIntelliRecognize
from ai.interface.Result import Result
from ai.utils.utils import ResultEncoder
import logging

# app = Flask(__name__)

logging.basicConfig(
    level=logging.DEBUG,  # 设置日志级别，这里设置为DEBUG，可以记录DEBUG及以上级别的日志
    format='%(asctime)s -%(name)s- %(levelname)s - %(message)s',  # 设置日志格式
    datefmt='%Y-%m-%d %H:%M:%S',  # 设置时间格式
    filename=None,  # 指定日志文件名，如'app.log'，如果不设置则默认输出到控制台,
    filemode='w'  # 指定文件模式，'w'或'a'，'w'表示每次运行都会清空原日志文件重新写入，'a'表示追加模式
)


# @app.route('/')
def hello_world():  # put application's code here
    return 'Hello World!!!!'


def get_excel_resource():
    path_join = os.path.join(os.getcwd(), 'resources', '投保人1.xlsx')
    return pd.ExcelFile(path_join, engine='openpyxl')


def get_excel_str():
    s = '''
    編號	職位	姓名	身份證號	生日	保險類型	地址
1	藝人	魏如萱	U221197277	1982.10.10	高端款	上海浦东新区上丰路1158号
2	經紀人	李福軍	O200028693	1983.08.11	高端款	上海浦东新区上丰路1159号
3	音響工程師	林明賢	N123116576	1977.05.13		上海浦东新区上丰路1160号
4	音響工程師	麥嘉文	K122349480	1988.07.20		上海浦东新区上丰路1161号
5	音響工程師	姜智傑	F125436137	1981.07.29		上海浦东新区上丰路1162号
6	燈光設計師	吳承翰	S123312803	1987.07.14		上海浦东新区上丰路1163号
7	燈光設計師	梁庭語	F126860333	1987.02.18		上海浦东新区上丰路1164号
8	VJ	張聖壯	G121878201	1986.04.04		上海浦东新区上丰路1165号
9	YASSS!製作人	洪冠喬	A228269724	1984.11.04		上海浦东新区上丰路1166号
10	YASSS!staff	林筵葦	D122758198	1992.11.19		上海浦东新区上丰路1167号
11	樂隊助理	徐莉婷	F228829396	1995.05.08		上海浦东新区上丰路1168号
12	吉他手	韓立康	A124305665	1982.04.02		上海浦东新区上丰路1169号
13	鼓手	賴聖文	A125402029	1981.05.25		上海浦东新区上丰路1170号
14	鍵盤手	張瀚中	F126173639	1984.03.24		上海浦东新区上丰路1171号
15	貝斯手	柯遵毓	B121821770	1984.03.27		上海浦东新区上丰路1172号
16	音樂編程	張育維	R124072110	1990.10.08		上海浦东新区上丰路1173号
17	吉他手2	蔣希夷	F129929964	1997.10.26		上海浦东新区上丰路1174号
18	監製	陳建騏	S120217490	1973.02.03	高端款	上海浦东新区上丰路1175号
19	執行經紀	趙子喬	A230142907	1999.06.01		上海浦东新区上丰路1176号
20	動態攝影	陸韋中	T123767603	1992.01.30		上海浦东新区上丰路1177号
21	髮型師	林中韓	A125913250	1983.12.22		上海浦东新区上丰路1178号
    '''
    return s


if __name__ == '__main__':
    # app.run()
    # paste = pyperclip.paste()
    # logging.info(f'paste:{paste}')
    # result = HanlpExcelIntelliRecognize().recognize(get_excel_resource(), result_type=Result)
    result = HanlpStrIntelliRecognize().recognize(get_excel_str(), result_type=Result)
    # print(json.dumps(result, cls=ResultEncoder))
    # print(pyperclip.paste())
