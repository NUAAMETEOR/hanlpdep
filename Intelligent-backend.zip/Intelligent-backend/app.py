from flask import Flask
import os
import pandas as pd
import json
import pyperclip
from ai.hanlp.HanlpIntelliRecognize import HanlpIntelliRecognize
from ai.utils.utils import ResultEncoder

# app = Flask(__name__)


# @app.route('/')
def hello_world():  # put application's code here
    return 'Hello World!!!!'


def get_excel_resource():
    path_join = os.path.join(os.getcwd(), 'resources', '投保人1.xlsx')
    return pd.ExcelFile(path_join, engine='openpyxl')


if __name__ == '__main__':
    # app.run()

    result = HanlpIntelliRecognize().recognize_excel_file(get_excel_resource())
    print(json.dumps(result, cls=ResultEncoder))
    # print(pyperclip.paste())
